SCAMPEER GamepadViewer Overlay Pack

Files:
- scampeer_controller_overlay_transparent.png
- scampeer-controller.css

Basic use:
1. Host both files in the same public HTTPS folder.
   Good options: GitHub Pages, Netlify, Cloudflare Pages, or your own web server with HTTPS.
2. Open this URL format:
   https://gamepadviewer.com/?p=1&css=https://YOUR-HOST/scampeer-controller.css
3. In OBS, add a Browser Source using that URL.
4. Set width/height to 1254 x 1254 first, then scale it down in OBS.
5. Connect/controller press any button so GamepadViewer detects it.

Notes:
- This is a starter live skin. The base art is ready. The CSS creates glow overlays for pressed inputs.
- You may need minor coordinate adjustments after seeing it live in OBS.
- The PNG alone can also be used as a static OBS Image Source, but it will not animate by itself.
